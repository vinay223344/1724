/*
 ============================================================================
 Name        : 10_Menu_Operations.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <math.h>

void prime()
{
	int flag;
	for(int i=2;i<50;i++)
	{
		flag = 0;
		for(int j=2;j<=i/2;j++)
		{
			if(i % j == 0)
			{
				flag = 1;
				break;
			}
		}
		if(flag == 0) printf("%d ",i);
	}
}

void palindrome()
{
	int num, n, rem, rev = 0;
	printf("Enter a number: ");
	scanf("%d", &num);
	n = num;
	while(num > 0)
	{
		rem = num % 10;
		rev = rev * 10 + rem;
		num = num / 10;
	}
	if(n == rev)
	{
		printf("%d is a palindrome\n", n);
	}
	else
	{
		printf("%d is not a palindrome\n", n);
	}
}

int check()
{
	char c;
	__fpurge(stdin);
	scanf("%c", &c);
	if(c == '\n') return 1;
	else return 0;
}

void infinite_welcome()
{
	int i,j;
	for(j=0;j<1000;j++)
	{
		i = check();
		if(i == 0)
			printf("welcome");
		else
			break;
	}
}



void operations() {
	char choice;
	while(1)
	{
		printf("A. Display 'WELCOME to MOSCHIP'\n");
		printf("a. Display prime numbers from 1 to 50");
		printf("[1-9]. Left shift value by 3\n");
		printf("K. Display welcome until interupted\n");
		printf("P. Check if a number is palindrome or not\n");
		printf("Select an operation: ");
		__fpurge(stdin);
		scanf("%c", &choice);
		switch(choice)
		{
		case 'A': printf("WELCOME to MOSCHIP"); break;
		case 'a': prime(); break;
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9': printf("%d", choice << 3); break;
		case 'K': infinite_welcome(); break;
		case 'P': palindrome(); break;
		default: printf("Invalid choice");
		}
	}
}


void bit_operations()
{
	char choice;
	while(1)
	{
		printf("A. Display 'WELCOME to MOSCHIP'\n");
		printf("a. Display prime numbers from 1 to 50");
		printf("[1-9]. Left shift value by 3\n");
		printf("K. Display welcome until interupted\n");
		printf("P. Check if a number is palindrome or not\n");
		printf("Select an operation: ");
		__fpurge(stdin);
		scanf("%c", &choice);
		switch(choice)
		{
		case 'A': printf("WELCOME to MOSCHIP"); break;
		case 'a': prime(); break;
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9': printf("%d", choice << 3); break;
		case 'K': infinite_welcome(); break;
		case 'P': palindrome(); break;
		default: printf("Invalid choice");
		}
	}
}

int main()
{
	int n;
    while(1)
	{
		printf("Enter question number(1-11): ");
		scanf("%d", &n);
		switch(n)
		{
		case 1: operations(); break;
		case 2: bit_manipulation(); break;
		}
		printf("\n");
	}
	return 0;
}




