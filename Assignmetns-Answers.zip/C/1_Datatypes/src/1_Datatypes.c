/*
 ============================================================================
 Name        : 1_Datatypes.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>

//1.
void format_specifiers() {
    int a=4000,b=200,c=15; // Defining variables
    printf("a=%d\nb=%d\nc=%d\n",a,b,c);
    printf("%a=%4d\n%b=%4d\n%c=%4d",a,a,b,b,c,c);
}
/*Output: 	a=4000
			b=200
			c=15
			0x1.9999999999999p-614=4000
			111110100000= 200
			�=  15
*/
/* Explanation: %a -> To print the number in hexadecimal exponential format(mantissa, exponent)
 	 	 	    %b -> To print the number in binary format
 	 	 	    %c -> To print the ASCII character corresponding to the number
*/

//2.
void ASCII_char_and_value()
{
    char mc='2'; // Defining a character variable
	printf("mc=%c %d\n",mc,mc); // %c-->character %d-->respective ASCII value
	mc=mc*2;
	printf("mc=%c %d\n",mc,mc);
	mc*=2;
	printf("mc=%c %d\n",mc,mc);
}
/*Output: 	mc=2 50
			mc=100 d
			mc=� -56
*/
/* Explanation: 1. Character is '2' and its corresponding ASCII value '50' is printed.
 	 	 	 	2. When arithmetic operation is performed, the 50 is changed to 100 and its corresponding ASCII character 'd' is printed.
 	 	 	 	3. Since char ranges from -128 to 127, 200 is out of range and is wraped around to -56, and ASCII character corresponding to 200 is printed..
*/

//3
void var_unsigned()
{
	short int s1=0,s2=0;
	unsigned short int u1=0, u2=0;
	printf("s1=%hd s2=%hd\n",s1,s2);
	printf("u1=%hd u2=%hd\n",u1,u2);
	s2=s1-1;
	u2=u1-1;
	printf("s1=%hd s2=%hd\n",s1,s2);
	printf("u1=%hd u2=%hd\n",u1,u2);
}
/*Output: 	s1=0 s2=0
			u1=0 u2=0
			s1=0 s2=-1
			u1=0 u2=-1
*/
/* Explanation: As format specifier is %d, u2, though is unsigned, is typecasted to signed, and hence -1 is printed. This can be verified by printing it using %u */

//4.
void value_change()
{
	short int x=55,y=6;
	printf("x=%d y=%d\n",x,y);
	printf("Enter two integers:");
	scanf("%hd %hd",&x,&y);
	printf("x=%d y=%d\n",x,y);
}
/*Output: 	x=55 y=6
			Enter two integers:1 20
			x=1 y=20
*/
/* Explanation: Values of x and y initially declared are overwritten by the values from the user. */

//5.
void range_unsigned_short_int()
{
	unsigned short int var=0;
	printf("var = %hu\n",var);
	--var;
	printf("var = %hu\n",var);
}
/*Output: 	var = 0
			var = 65535
*/

//6.
void range_unsigned_int()
{
	unsigned int var=0;
	printf("var = %u\n",var);
	var=var-1;
	printf("var = %u\n",var);
}
/*Output: 	var = 0
			var = 4294967295
*/

//7.
void range_unsigned_long_int()
{
	unsigned long int var=0;
	printf("var = %lu\n",var);
	var=var-1;
	printf("var = %lu\n",var);
}
/*Output: 	var = 0
			var = 18446744073709551615
*/

//8.
void val_increment()
{
	int a=10;
	printf("a=%d\n",a);
	++a;
	printf("a=%d\n",a);
	a++;
	printf("a=%d\n",a);
	--a;
	printf("a=%d\n",a);
	a--;
	printf("a=%d\n",a);
}
/*Output: 	a=10
			a=11
			a=12
			a=11
			a=10
*/

//9.
void val_increment_assign()
{
	int x=10,y=0;
	int i=10,j=0;
	printf("x=%d y=%d\n",x,y);
	printf("i=%d j=%d\n",i,j);
	y=++x; // Value of x is incremented first and then assigned to y
	j=i++; // Value of i is assigned to j and then incremented
	printf("x=%d y=%d\n",x,y);
	printf("i=%d j=%d\n",i,j);
}
/*Output: 	x=10 y=0
			i=10 j=0
			x=11 y=11
			i=11 j=10
*/

//10.
void float_division()
{
	float v=34.5;
	printf("v=%f\n",v);
	v=v/2;
	printf("v=%f\n",v);
}
/*Output: 	v=34.500000
			v=17.250000
*/
/* Explanation: Default number of digits after decimal point in %f specifier is 6 */

//11.
void exp_format_specifier()
{
	float v=1234.5;
	printf("v=%e %f\n",v,v);
	v=v*100;
	printf("v=%e %f\n",v,v);
	v=3.4;
	printf("v=%e %f\n",v,v);
	v=0.000567;
	printf("v=%e %f\n",v,v);
}
/*Output: 	v=1.234500e+03 1234.500000
			v=1.234500e+05 123450.000000
			v=3.400000e+00 3.400000
			v=5.670000e-04 0.000567
*/
/* Explanation: %e is format specifier to print a number in exponential form */

//12.
void number_systems()
{
	int a=20,b=021,c=0x22;
	int d;
	d=a+b+c;
	printf("d=%d %o %x\n",d,d,d);
}
/*Output: 	d=71 107 47 */
/* Explanation: The value of d, that is 71, is printed in 3 different number system formats */

//13. Program to print the size of the data types: int, float, char and double
void sizeof_datatype()
{
	printf("Size of int: %d\n",sizeof(int));
	printf("Size of float: %d\n",sizeof(float));
	printf("Size of double: %d\n",sizeof(double));
	printf("Size of char: %d\n",sizeof(char));
}
/*Output: 	Size of int: 4
			Size of float: 4
			Size of double: 8
			Size of char: 1
*/

//14. Program to test if a given character is: Lowercase letter, Uppercase letter, Digit, Whitespace(space, tab, newline) operators
void read_character()
{
	char c;
		printf("Enter the character: ");
		__fpurge(stdin);
		scanf("%c", &c); // Reading character from user
		if(c>='a' && c<='z') // If character is between a and z
		{
			printf("The character is a lowercase letter");
		}
		else if(c>='A' && c<='Z') // If character is between A and Z
		{
			printf("The character is an uppercase letter");
		}
		else if(c>='0' && c<='9') // If character is between 0 and 9
		{
			printf("The character is a digit");
		}
		else if(c==' ' || c=='\t' || c=='\n') // If character is space, tabspace or newline
		{
			printf("The character is a whitespace");
		}
		else
		{
			printf("Invalid character");
		}
}
/*Output: 	Enter the character: R
			The character is an uppercase letter
			Enter the character: u
			The character is a lowercase letter
			Enter the character: 9
			The character is a digit
			Enter the character:
			The character is a space
			Enter the character:
			The character is a tab space
			Enter the character:
			The character is a new line
*/

/*15. What is complilation process? What are the stages involved in this process? */
void compilation()
{
	printf("Compilation Process: It is the process of converting the program to a machine language.\n"
		   "a. Preprocessing: Expands macros, preprocessor directives(.i file)\n"
		   "b. Compiling: Checks syntax and converts code to low level language(.s file)\n"
		   "c. Linking: Links external files, libraries, functions(.o file)\n"
		   "d. Assembling: Loads executible files(.exe file)\n");
}
/* Output: Compilation Process: It is the process of converting the program to a machine language.
		   a. Preprocessing: Expands macros, preprocessor directives(.i file)
		   b. Compiling: Checks syntax and converts code to low level language(.s file)
		   c. Linking: Links external files, libraries, functions(.o file)
		   d. Assembling: Loads executable files(.exe file)
*/

int main()
{
	int n;
		while(1)
		{
			printf("Enter question number(1-15): ");
			scanf("%d",&n);
			switch(n)
			{
			case 1: format_specifiers(); break;
			case 2: ASCII_char_and_value(); break;
			case 3: var_unsigned(); break;
			case 4: value_change(); break;
			case 5: range_unsigned_short_int(); break;
			case 6: range_unsigned_int(); break;
			case 7: range_unsigned_long_int(); break;
			case 8: val_increment(); break;
			case 9: val_increment_assign(); break;
			case 10: float_division(); break;
			case 11: exp_format_specifier(); break;
			case 12: number_systems(); break;
			case 13: sizeof_datatype(); break;
			case 14: read_character(); break;
			case 15: compilation(); break;
			}
			printf("\n");
		}
		return 0;
}
