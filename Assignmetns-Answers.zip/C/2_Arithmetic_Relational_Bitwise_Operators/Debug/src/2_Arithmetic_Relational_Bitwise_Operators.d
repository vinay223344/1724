src/2_Arithmetic_Relational_Bitwise_Operators.o: \
 ../src/2_Arithmetic_Relational_Bitwise_Operators.c
