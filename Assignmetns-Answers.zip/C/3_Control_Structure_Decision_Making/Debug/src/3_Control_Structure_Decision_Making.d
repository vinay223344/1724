src/3_Control_Structure_Decision_Making.o: \
 ../src/3_Control_Structure_Decision_Making.c
