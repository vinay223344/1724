src/4_Control_Structure_Decision_Making.o: \
 ../src/4_Control_Structure_Decision_Making.c
