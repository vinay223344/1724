src/5_Control_Structure_Decision_Making.o: \
 ../src/5_Control_Structure_Decision_Making.c
