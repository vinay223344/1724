/*
 ============================================================================
 Name        : 5_Control_Structure_Decision_Making.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>

// 1. Program to print the type(category) of user supplied char from stdin. The categories are Numeric/ Uppercase/ Lowercase/ Spl. Character
void read_char()
{
	char ch;
	int option;
	printf("1. Using If/else\n2. Using Conditional Operator\nSelect an option: ");
	scanf("%d", &option);
	if(option == 1)
	{
		printf("Enter a character: ");
		__fpurge(stdin);
		scanf("%c", &ch);
		if(ch >= '0' && ch <= '9')
		{
			printf("The character is a digit");
		}
		else if(ch >= 'A' && ch <= 'Z')
		{
			printf("The character is an uppercase alphabet");
		}
		else if(ch >= 'a' && ch <= 'z')
		{
			printf("The character is a lowercase alphabet");
		}
		else if(ch == '!' || ch == '@' || ch == '#' || ch == '%' || ch == '&') // ascii values are in ranges, so just few examples are taken here
		{
			printf("The character is a special character");
		}
	}
	else if(option == 2)
	{
		printf("Enter a character: ");
		__fpurge(stdin);
		scanf("%c", &ch);
		(ch >= '0' && ch <= '9') ? printf("Digit") : (ch >= 'A' && ch <= 'Z') ? printf("Uppercase Character") : (ch >= 'a' && ch <= 'z') ? printf("Lowercase Character") : printf("Special Character");
	}

}
/* Output:  1. Using If/else
			2. Using Conditional Operator
			Select an option: 2
			Enter a character: A
			Uppercase Character
*/

//2. Program to test the status of a bit in a specified integer.
void check_bit_status()
{
	int num,pos,res, status;
	printf("Enter number and bit to be checked separated by space: ");
	scanf("%d %d", &num, &pos);
	res = (num>>pos) & 1; // Right shift bits by the position of the bit to be checked and & it with 1
	printf("%d", status);
}
/* Output: Enter number and bit to be checked separated by space: 12 2
           1
*/
/* Explanation: 1100 -> 2nd bit = 1 */

// 3. Program to evaluate and find out which expression is appropriate and equal to x % y
void check_equivalence()
{
	int x, y;
	printf("Enter two integers: ");
	scanf("%d %d", &x, &y);
	if(x%y == y - (x/y) * x)
	{
		printf("x % y = y - (x/y) * x");
	}
	else if(x%y == x - (x/y) * y)
	{
		printf("x % y = x - (x/y) * y");
	}
	else if(x%y == x - (x/y) * y)
	{
		printf("x % y = x - (x/y) * y");
	}
	else if(x%y == y - (y/x) * y)
	{
		printf("x % y = y - (y/x) * y");
	}
}
/* Output: Enter two integers: 5 2
		   x % y = x - (x/y) * y
*/

// 4.
void size_of()
{
	int x, y;
	x = 10;
	y = sizeof(++x);
	printf("x = %d y = %d", x, y);
}
/* Output: x = 10 y = 4 */
/* Explanation: 'sizeof' operators doesn't evaluate any expressions, it just sees the variable. It is a 'Compile-Time operator'. */

// 5.
void op_precedence1()
{
	int x = !0 * 20;
	printf("%d", x);
}
/* Output: 20 */
/* Explanation: x = !0 * 20 => x = 1 * 20 => x = 20
 	 	 	 	Logical not has higher precedence than multiplication
*/

//6.
void op_precedence2()
{
	int a=3, b=4, c;
	c = b==4 || a!=3;
	printf("%d", c);
}
/* Output: 1 */
/* Explanation: c = b==4 || a != 3 => c = 1 || (not evaluated) => c = 1
 	 	 	 	The first expression is true, so second expression is not evaluated.
*/

// 7. Program to explore a scenario where a 'raise flag' is modified within any function and accessed in the other function. If that flag is '1', make result variable '1' else '0'. If the flag is '0', the code should wait on testing the raise flag
int raise = 0; // think of 'volatile'
void isRaise()
{
	raise = 1;
}
void raise_bit()
{
	int result = 0;
	if(raise == 1)
	{
		result = 1;
		printf("Result: %d", result);
	}
	else
	{
		isRaise();
		raise_bit();
	}
}
/* Output: Result: 1*/

//8. Difference between unsigned int and signed int in C
void signed_unsigned_int_diff()
{
	printf("Range of unsigned int: 0 to 2^32 - 1\n"
			"Range of signed int: -2^31 to 2^31 - 1\n"
			"Size both signed and unsigned int is 4 Bytes\n"
			"Unsigned int is accesed by format specifier: %%u\n"
			"Signed int is accessed by format specifier: %%d\n"
			"Default is signed int");
}
/* Output: Range of unsigned int: 0 to 2^32 - 1
		   Range of signed int: -2^31 to 2^31 - 1
		   Size both signed and unsigned int is 4 Bytes
		   Unsigned int is accesed by format specifier: %u
		   Signed int is accessed by format specifier: %d
		   Default is signed int
*/

// 9. Program to write a for loop without initialization, condition or increment
void infinite_for_loop()
{
	//for(;;);  // Infinite loop
	printf("This is for loop without initialization, condition or increment");
}

// 10.
void for_loop_semicolon()
{
	int i = 0;
	for(i = 0; i < 5; i++);
	printf("%d ", i);
}
/* Output: 5 */
/* Explanation: The loop executes for 5 times, at the end, the value of i is 5 and hence is printed */

// 11.
void char_unsigned()
{
	unsigned char x = 250;
	for(; x >= 0; x--)
	{
		printf("%u ", x);
		if(x == 0) break;
	}
}
/* Output: 250 249 248 247 246 245 244 243 242 241 240 239 238 237 236 235 234 233 232 231 230 229 228 227 226 225 224 223 222 221 220 219 218 217 216 215 214 213 212 211 210 209 208 207 206 205 204 203 202 201 200 199 198 197 196 195 194 193 192 191 190 189 188 187 186 185 184 183 182 181 180 179 178 177 176 175 174 173 172 171 170 169 168 167 166 165 164 163 162 161 160 159 158 157 156 155 154 153 152 151 150 149 148 147 146 145 144 143 142 141 140 139 138 137 136 135 134 133 132 131 130 129 128 127 126 125 124 123 122 121 120 119 118 117 116 115 114 113 112 111 110 109 108 107 106 105 104 103 102 101 100 99 98 97 96 95 94 93 92 91 90 89 88 87 86 85 84 83 82 81 80 79 78 77 76 75 74 73 72 71 70 69 68 67 66 65 64 63 62 61 60 59 58 57 56 55 54 53 52 51 50 49 48 47 46 45 44 43 42 41 40 39 38 37 36 35 34 33 32 31 30 29 28 27 26 25 24 23 22 21 20 19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1 0 */

// 12.
int ternary_return()
{
	int x = 1, y = 0, z = 3;
	// x>y ? printf("%d",z) : return z; => ERROR: return is a statement, only expressions can be used in ternary
	if(x>y)
	{
		printf("%d",z);
	}
	else
	{
		return z;
	}
	return 0;
}
/* Output: 3 */

// 13.
void neg_division()
{
	int i = -3;
	int k = i % 2;
	printf("%d\n", k);
}
/* Output: -1 */
/* Explanation: -3 / 2 = -1 => Remainder = -0.5 => floor(-0.5) = -1 */

// 14. Program to swap lower nibbles
void nibble_swap()
{
	int i, res1, res2, res;
	printf("Enter a number in hexadecimal representation: ");
	scanf("%x", &i);
	res1 = (i & 0X00FF00FF) << 8;
	res2 = (i & 0XFF00FF00) >> 8;
	res = res1 | res2;
	printf("%x", res);
}
/* Output: 3412 */
/* Explanation: res1 = 1234 & 00FF => 0034 << 8 =>  3400
 	 	 	 	res2 = 1234 & FF00 => 1200 >> 8 => 0012
 	 	 	 	res = res1 | res2 => 3412
*/

// Main function
int main()
{
	int n;
	while(1)
	{
		printf("Enter question number(1-14): ");
		scanf("%d", &n);
		switch(n)
		{
		case 1: read_char(); break;
		case 2: check_bit_status(); break;
		case 3: check_equivalence(); break;
		case 4: size_of(); break;
		case 5: op_precedence1(); break;
		case 6: op_precedence2(); break;
		case 7: raise_bit(); break;
		case 8: signed_unsigned_int_diff(); break;
		case 9: infinite_for_loop(); break;
		case 10: for_loop_semicolon(); break;
		case 11: char_unsigned(); break;
		case 12: printf("\nReturn: %d", ternary_return()); break;
		case 13: neg_division(); break;
		case 14: nibble_swap(); break;
		default: printf("Invalid Input");
		}
		printf("\n");
	}
	return 0;
}
