/*
 ============================================================================
 Name        : 6_Preprocessor_Derivatives.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include<stdio.h>

// 1.
void p1()
{
	#define X 5
	#if !X
	printf("Good");
	#else
	printf("Bad");
	#endif
}
/* Output: Bad */
/* Explanation: !5 = 0 => condition false */

#define x 7+5
void p2()
{
	int i;
	i = x * x * x; // 7+5*7+5*7+5 = 7+35+35+5 = 82
	printf("%d ",i);
}
// Output: 82


#define _ms(x) ++x * ++x
void p3()
{
	int a = 3, z;
	z = ++a * ++a;
	a -= 3;
	printf("%d %d", _ms(a), z);
}
// Output: 16 25
/* Explanation: z = 4 * 5 => When the value is changed in second part of expression, it updates the previous one too => 5 *5 =25
  				a = 5 - 3 = 2
  				_ms(a) => 3 * 4 => 4 * 4 = 16
*/

#define loop while(1)
void p4()
{
	loop // Loops Infinitely
	printf("moschip india ");
}


void p5()
{
	//#define int double
	int temp=12345;
	printf("%d ",sizeof(temp));
}
// Output: 8


#define NODE(a) a*10+2
void p6()
{
	int a=NODE(2)*2; // 2*10+2*2 => 20+4 = 24
	printf("%d ",a);
}
// Output: 24


#define LOOP(a) int i; for(i=1;i<=a;i++); printf("%d ",i);
void p7(){
	LOOP(5);
}
// Output: 6


#define v 9
void p8()
{
	int b;
	#define v 10 // Value of v is 10 locally, outside this function, its value remains 9
	b=v*5;
	printf("%d",b);
}
// Output: 50


#define big(a,b) a > b ? a : b
#define swap(a,b) temp=a; a=b; b=temp;
void p9()
{
	int a=3,b=5,temp=0;
	if ((3+big(a,b)) > b) swap(a,b);
	printf(" %d %d",a,b);
}
// Output: 5 0
/* Explanation: if (3+3>5?3:5 > 5)  Condition false
					temp  = 3; Only first statement is taken under if
				a = 5;
				b = 0;
   Macros just expand, they are just substituted in place of their call
*/


#define calc(a, b) (a * b) / (a - b)
void p10()
{
	int a = 20, b = 10;
	printf("%d", calc(a + 4, b -2));
}
// Output: 4
/*Explanation: (20+4*10-2) / (20+4-10-2) => (20+40-2) / (24-10-2) => 58/12 => 4 */

#define y 10//; // semicolon error
void p11(){
	printf("%d", y);
}
// Output = 10

#define c 10 // Even if c value is not specified, as its ifdef, the program executes without error
void p12()
{
	#ifdef c
	printf("MOSCHIP ");
	#endif
	#ifndef c
	printf("INDIA\n");#else
	printf("HYDERABAD\n");
	#endif
}
/* Output: MOSCHIP */

void p13()
{
	#define max 100
	#ifdef max
	printf("Hello");
	#endif // When no #endif, ERROR
}
// Output: Hello

#define max 100
void p14()
{
	#if(max%10)
	printf("MOSCHIP ");
	#endif
	printf("INDIA");
}
// Output: INDIA

void p15()
{
	#if X == 3
	#define Y 3
	#else
	#define Y 5
	#endif
	printf("%d", Y);
}
// Output: 5

#define ISEQUAL(A, B) A == B
#define VAL !1
void p16()
{
	#if ISEQUAL(VAL, 0)
	printf("OK");
	#else
	printf("NOT OK");
	#endif
}
//Output: OK

#define MAXI 1000
void p17()
{
	//int MAXI = 100; // ERROR: As MAXI is substitiuted as 1000 and variable name should not start with a digit
	printf("%d ", MAXI);
}

#define A -B
#define B -C
#define C 5
void p18()
{
	printf("The value of A is %d\n", A);
}
// Output: The value of A is 5
/* Explanation:  B = -C = -5 => A = -B = 5 */

#define hello(x) printf("a"#x" = %d",a##x)
#define A3
void p19()
{
	int a3=45;
	#ifdef A3
	hello(3);
	#else
	printf("MOSCHIP");
	#endif
}
// Output: a3 = 45
/* Explanation: '#' -> stringizies the following variable
 	 	 	 	'##'-> Concatenating  two tokens into a single one -> Token pasting operator
 */

#define hello(w) printf("a"#w" = %d",a##w)
int a3=45;
void p20()
{
	#ifdef a3
	hello(3);
	#else
	printf("MOSCHIP");
	#endif
}
// Output: MOSCHIP

#define hello(v) #v
void p21()
{
    //printf(hello(MOSCHIP, HYDERABAD)); // Two arguments in hello, whereas in definition only one is there
	printf(hello(MOSCHIP));
}
// Output: MOSCHIP

#define print(h,i) #h #i
void p22()
{
	printf(print(hello,"World!"));
}
// Output: hello"World!"

#define VAL 10
void p23()
{
	#ifdef VAL
	#undef VAL
	#define VAL 100
	#else
	#define VAL 2000
	#endif
	printf("%d\n",VAL);
}
// Output: 100

void fun()
{
	#define VAL1 100
	printf("%d\n",VAL1);
}
void p24()
{
	#define VAL1 200
	fun();
	printf("%d\n",VAL1);
}
/* Output: 100
	       200
*/

#define print(x) printf(#x "...")
void p25()
{
	print(Hi);
	print(Good Morning!);
}
// Output: Hi...Good Morning!...

#define p(n,m) printf("%d ",m##n)
#define q(a,b) printf("%d ",a##b)
void p26()
{
	p(3,4);
	q(5,6);
}
// Output: 43 56

#define hello 10
void p27()
{
	printf("%d",hello);
	#undef hello
	//printf("%d",hello); //-> Error: as hello is undefined in the previous statement
}
// Output: 10

#define sf 10
void p28()
{
	if(sf==100)
	printf("good");
	else
	{
	printf("bad");
	//sf=100; //-> sf = 10 -> 10 = 100 -> Invalid
	}
	printf("%d",sf);
}
// Output: bad10


# define a 10
void p29()
{
	printf("%d..", a);
	foo();
	printf("%d", a);
}
void foo()
{
	#undef a
	#define a 50
}
// Output: 10..10

#define CUBE(n) n*n*n
void p30()
{
	int k,b=3;
	k=CUBE(b++); // b++ * b++ * b++ => 3 * 4 * 5 => 60
	printf("%d %d",k,b); // 60 6
}
// Output: 60 6

// Main function
int main()
{
	int n;
	while(1)
	{
		printf("Enter question number(1-26): ");
		scanf("%d", &n);
		switch(n)
		{
		case 1: p1(); break;
		case 2: p2(); break;
		case 3: p3(); break;
		case 4: p4(); break;
		case 5: p5(); break;
		case 6: p6(); break;
		case 7: p7(); break;
		case 8: p8(); break;
		case 9: p9(); break;
		case 10: p10(); break;
		case 11: p11(); break;
		case 12: p12(); break;
		case 13: p13(); break;
		case 14: p14(); break;
		case 15: p15(); break;
		case 16: p16(); break;
		case 17: p17(); break;
		case 18: p18(); break;
		case 19: p19(); break;
		case 20: p20(); break;
		case 21: p21(); break;
		case 22: p22(); break;
		case 23: p23(); break;
		case 24: p24(); break;
		case 25: p25(); break;
		case 26: p26(); break;
		case 27: p27(); break;
		case 28: p28(); break;
		case 29: p29(); break;
		case 30: p30(); break;
		}
		printf("\n");
	}
	return 0;
}


