/*
 ============================================================================
 Name        : 7_Functions.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>

// 1. C function to print binary representation of a positive integer n using recursion
void binary(int n, int bin, int a)
{
	int rem = 0;
	if(n==0)
	{
		printf("%d",bin);// Print the binary number when the original number is 0
		return;
	}
	rem = n % 2;		// Obtain the rem when divided by 2
	bin = bin + rem * a;// Append the remainder to the binary number
	n = n / 2;			// Divide the number by 2
	a = a * 10;			// Change placevalue of 'a' so as to move the bin number a digit towards left
	binary(n, bin, a);  // Call the binary() function recursively
}
void dec_to_bin()
{
	int num, bin = 0, a = 1;
	printf("Enter a positive integer: ");
	scanf("%d", &num); // Read a positive integer
	binary(num,bin,a); // Call binary function with arguments: number, initialized binary, placevalue variable
}
/* Output: Enter a positive integer: 20
		   10100
*/

// 2. Function to check whether a given number is triangular number
void triangular(int n, int res, int increment)
{
	res = (res + increment++);
	if(n==res || n==1) // If given number is equal to triangular number, notify user and exit from this function
	{
		printf("Given number is triangular");
		return;
	}
	else if(n > res) // If number is greater than the present triangular number, recall the function
	{
		triangular(n, res, increment);
	}
	else // Else, notify user that the entered number is not triangular
	{
		printf("Given number is not triangular");
	}
}
void triangular_number()
{
	int n, res = 1, increment = 2; // n: user number; res = triangular number;
	printf("Enter a number: ");
	scanf("%d", &n);
	triangular(n, res, increment); // Call function to check if a number is triangular or not
}
/* Output:
    Enter a number: 15
	Given number is triangular
	Enter a number: 9
	Given number is not triangular
*/

//3. C function to find the reverse of an integer using recursion
void reverse(int n, int rev)
{
	int rem = 0;
	rem = n % 10;			// Extract units digit of the number
	rev = rev * 10 + rem;	// Append units digit to reversed number
	n = n / 10;				// Drop the units digit of the number
	if(n==0)				// If no more digits are there in number, print the reversed number and exit the function
	{
		printf("Reversed number: %d", rev);
		return;
	}
	reverse(n,rev);		// Recall the function
}
void num_rev()
{
	int num, rev = 0;
	printf("Enter a number: ");
	scanf("%d", &num);
	reverse(num, rev); // Call the function to reverse digits of a number
}
/* Output: Enter a number: 145698
	       Reversed number: 896541
*/

/* 4. Program to take price and quantity of multiple items from the user and Write:
		• A function to calculate subtotal.
		• A function to apply discount:
			o Total < 1000 → 5%
			o 1000 ≤ Total < 5000 → 10%
			o Total ≥ 5000 → 15%
		• A function to display a formatted bill.
*/
void discount(int totalAmount)
{
	int discount;
	printf("TOTAL\t\t\t\t %d\n", totalAmount);
	if(totalAmount < 1000)
	{
		discount = totalAmount * 0.05;
		printf("Discount 5%\t\t\t %d\n", -discount);
	}
	else if(totalAmount >= 1000 && totalAmount > 5000)
	{
		discount = totalAmount * 0.1;
		printf("Discount 10%\t\t\t %d\n", -discount);
	}
	else if(totalAmount >= 5000)
	{
		discount = totalAmount * 0.15;
		printf("Discount 15%\t\t\t %d\n", -discount);
	}
	printf("-----------------------------------------\n");
	printf("GRAND TOTAL\t\t\t %d", totalAmount - discount);
}
void subTotal(int numItems, int price[], int quantity[])
{
	int subTotal[numItems], totalAmount = 0;
	printf("Item\tPrice\tQuantity\tSubTotal\n");
	for(int i = 1; i <= numItems; i++)
	{
		subTotal[i] = price[i] * quantity[i];
		printf("Item %d\t  %d\t  %d\t\t%d\n",i,price[i],quantity[i],subTotal[i]);
		totalAmount += subTotal[i];
	}
	printf("-----------------------------------------\n");
	discount(totalAmount);
}
void customer()
{
	int quantity[10], price[10], numItems,i;
	printf("Enter the number of items: ");
	scanf("%d", &numItems);
	printf("Enter price and quantity of items: \n");
	for(i = 1; i <= numItems; i++)
	{
		printf("Item %d: ",i);
		scanf("%d %d",&price[i], &quantity[i]);
	}
	subTotal(numItems, price, quantity);
}
/* Output:  Enter the number of items: 3
			Enter price and quantity of items:
			Item 1: 20 6
			Item 2: 40 8
			Item 3: 45 4
			Item	Price	Quantity	SubTotal
			Item 1	  20	  6			120
			Item 2	  40	  8			320
			Item 3	  45	  4			180
			-----------------------------------------
			TOTAL						 620
			Discount 5%					 -31
			-----------------------------------------
			GRAND TOTAL					 589
*/

// 5. C function to check if a number contains 3 consecutive 5's in an array
void check5(int n, int count)
{
	int rem = 0;
	rem = n % 10;	        // Extract units digit of the number
	if(rem == 5)
	{
		count += 1;		    // If digit is 5, increment count
	}
	else
	{
		count = 0;
	}
	n = n / 10;				// Drop the units digit of the number
	if(count == 3)
	{
		printf("YES");	    // Print "YES" if three consecutive 5s are found
		return;
	}
	if(n == 0)				// If no more digits are there in number, print the reversed number and exit the function
	{
		printf("NO");
		return;
	}
	check5(n, count);	    // Recall the function
}
void consecutive_5()
{
	int num, count = 0;
	printf("Enter a number: ");
	scanf("%d", &num);
	check5(num, count);
}
/* Output:  Enter a number: 12564
			NO
			Enter a number: 125554
			YES
*/

/* 6. C Program to take number of units consumed and calculate total charge
	• First 200 units → ₹1/unit
	• Next 100 units → ₹1.5/unit
	• Beyond 300 units → ₹2/unit
*/
void unitCharge()
{
	int units, totalCharge = 0;
	printf("Enter number of units consumed: ");
	scanf("%d", &units);
	if(units <= 200)
	{
		totalCharge = units;
	}
	else if(units > 200 && units <= 300)
	{
		totalCharge = 200 * 1 + (units - 200) * 1.5;
	}
	else if(units > 300)
	{
		totalCharge = 200 * 1 + 100 * 1.5 + (units - 300) * 2;
	}
	printf("Total charge for consumed units: %d", totalCharge);
}
/* Output: Enter number of units consumed: 500
           Total charge for consumed units: 750
*/

/* 7. Define function in C. List the types of function. What are the benefits of
	  using more functions in C program?
*/
void function()
{
	printf("Definition: Function is a sub-program meant to do a specific task.\n"
			"Types of Functions: \n"
			"1. Library functions\n"
			"2. User-Defined Functions\n"
			"Benefits of using functions:\n"
			"1. Use of C functions modularizes and divides the code.\n"
			"2. Functions avoid repetition of block of code in a program.\n"
			"3. They make the program easy to understand, modify, debug and test.\n"
			"4. They are reusable.");
}
/* Output:  Definition: Function is a sub-program meant to do a specific task.
			Types of Functions:
			1. Library functions
			2. User-Defined Functions
			Benefits of using functions:
			1. Use of C functions modularizes and divides the code.
			2. Functions avoid repetition of block of code in a program.
			3. They make the program easy to understand, modify, debug and test.
			4. They are reusable.
*/

// 8. What is actual and formal argument?
void arguments()
{
	printf("Actual arguments: The arguments mentioned in the function call. These are values actually sent to the function.\n"
			"Formal arguments: The name of the arguments mentioned in the function definition. These are dummy arguments as they just hold the values sent by the calling function.");
}
/* Output: Actual arguments: The arguments mentioned in the function call. These are values actually sent to the function.
           Formal arguments: The name of the arguments mentioned in the function definition. These are dummy arguments as they just hold the values sent by the calling function.
*/

// 9.
int f(int num)
{
	return num*5;
}
void f_snippet1()
{
	int i = 3, val;
	val = f(i+=2) + f(i = 1) + f(i++); // f(5) + f(1) + f(1) => 5*5 + 1*5 + 1*5 => 25 + 5 + 5 = 35
	printf("%d %d", val, i);
}
/* Output: 35 2 */
/* Explanation: f(i+=2) => i is incremented by 2 and passed to function
 	 	 	 	f(i=1) => 1 is assigned to i and is passed to function
 	 	 	 	f(i++) => Value of i is passed to the function first, and then is incremented
*/

// 10.
int func(int i)
{
	if(i % 2) return 0;
	else return 1;
}
void f_snippet2()
{
	int i = 3;
	i = func(i);
	i = func(i);
	printf("%d", i);
}
/* Output: 1 */
/* Explanation: i = func(3) => 3%2=1 => returns 0
 	 	 	    i = func(0) => 0%2=0 => returns 1
*/

// 11.
void f_snippet3()
{
	int x;
	x = 3;
	f1(x);
	printf("MAIN");
}
void f1(int n)
{
	printf("F ");
	if(n!=0)
	f1(n-1);
}
/* Output: F F F F MAIN */
/* Explanation: n=3 => F is printed => n!=0 => true
 	 	 	 	n=2 => F is printed => n!=0 => true
 	 	 	 	n=1 => F is printed => n!=0 => true
 	 	 	 	n=0 => F => n!=0 => false => return to calling function
 	 	 	 	MAIN is printed
*/

int main()
{
	int n;
    while(1)
	{
		printf("Enter question number(1-11): ");
		scanf("%d", &n);
		switch(n)
		{
		case 1: dec_to_bin(); break;
		case 2: triangular_number(); break;
		case 3: num_rev(); break;
		case 4: customer(); break;
		case 5: consecutive_5(); break;
		case 6: unitCharge(); break;
		case 7: function(); break;
		case 8: arguments(); break;
		case 9: f_snippet1(); break;
		case 10: f_snippet2(); break;
		case 11: f_snippet3(); break;
		}
		printf("\n");
	}
	return 0;
}
