src/8_Storage_Classes.o: ../src/8_Storage_Classes.c
