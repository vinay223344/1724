src/inc.o: ../src/inc.c
