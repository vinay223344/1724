src/inc2.o: ../src/inc2.c
