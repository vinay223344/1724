################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/8_Storage_Classes.c \
../src/inc.c \
../src/inc2.c \
../src/sum.c 

C_DEPS += \
./src/8_Storage_Classes.d \
./src/inc.d \
./src/inc2.d \
./src/sum.d 

OBJS += \
./src/8_Storage_Classes.o \
./src/inc.o \
./src/inc2.o \
./src/sum.o 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c src/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GCC C Compiler'
	gcc -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-src

clean-src:
	-$(RM) ./src/8_Storage_Classes.d ./src/8_Storage_Classes.o ./src/inc.d ./src/inc.o ./src/inc2.d ./src/inc2.o ./src/sum.d ./src/sum.o

.PHONY: clean-src

