/*
 ============================================================================
 Name        : 8_Storage_Classes.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>

// 1.
int x = 10;
void inc(void);
void global_extern_static_1()
{
	printf("%d ",x);
	inc();
	printf("%d ",x);
	inc();
	printf("%d ",x);
	inc();
	printf("%d ",x);
}
// Output: 10 11 12 13
/* As the variable x is accessed in the file 'inc.c', any operation on it will be done in the same memory location and hence reflected even in this file */

// 2.
// static int x = 10;
void inc2(void);
void global_extern_static_2()
{
	printf("%d ",x);
	inc2();
	printf("%d ",x);
	inc2();
	printf("%d ",x);
	inc2();
	printf("%d ",x);
}
// Output: ERROR
/* Static specifier is used for information hiding. If an external variable is defined as static, then it can't be used by other files of the program */

// 3.
void global()
{
	int y = x;
	int z = y;
	printf("%d %d %d", x, y, z);
}
// Output: 13 13 13
/* The variable x is global variable and hence it can be accessed anywhere in the program. Here its value is assigned to y and z */

// 6.
int sum(int, int);
void sum_main()
{
	int x = 10, y = 20;
	printf("%d", sum(x,y));
}
// Output: 30
/* 'sum' function in sum.c file returns the sum of the actual arguments passed to it */

// 7.
/*
void register_variable()
{
	register int x = 10;
	printf("%p",&x);
}*/
/* Explanation: Register variables don't have memory address */

// 8.
int a, b, c;
void print_fun(void);
void print_main()
{
	static int a = 1;
	print_fun(); // 1 + 2 = 3; a=4, b=2
	a += 1;
	print_fun(); // 3 + 2 = 5; a=6, b=2
	printf("\n%d %d", a, b); // a = 2, b = 0
}
void print_fun(void)
{
	static int a = 2;
	int b = 1;
	a += ++b;
	printf("\n%d %d", a, b);
}
/* Output:
			4 2
			6 2
			2 0
*/
/* Explanation: Static variables are initialized only once per function.
                Their lifetime is till the end of the program.
                Since 'b' is a global variable, it is stored in data section and hence its default value is zero.
*/

// 9.
int tmp = 20;
void func_main()
{
	printf("%d ",tmp);
	func();
	printf("%d ",tmp);
}
void func()
{
	static int tmp = 10;
	printf("%d ",tmp);
}
/* Output: 20 10 20 */
/* Explanation: tmp is global variable, its value is changed to 10 in the 'func' function and it is static int specific only to that function. */

// 11.
int f(int n)
{
	static int r = 0;
	if(n <= 0) return 1;
	if(n > 3)
	{
		r = n;
		return f(n-2)+2;
	}
	return f(n-1)+r;
}
void f_main()
{
	printf("%d",f(5));
}
// Output: 18
/* Explanation: f(5) =>

/*
// 12.
void main_12()
{
	extern int i;
	printf("%d",i);
	{
		int i = 10;
		printf("%d", i);
	}
}
*/

// 13.
int funt(int n)
{
	static int s = 0;
	s = s + n;
	return(s);
}
void funt_main()
{
	int i = 10, x;
	while(i>0)
	{
		x = funt(i);
		i--;
	}
	printf("%d",x);
}
// Output: 5

/*
// 14.
void compare()
{
	int x = 10;
	//static int y = x; // ERROR
	if(x == y)
		printf("Equal");
	else if (x > y)
		printf("Greater");
	else
		printf("Less");
}*/
// Explanation: Static variable cannot be assigned another variable. It shd be assigned only a constant or an expression.

// 15.
int fun()
{
	static int num = 16;
	return num--;
}
void fun_main()
{
	for(fun(); fun(); fun())
		printf("%d ", fun());
}
// Output: 14 11 8 5 2

// 16.
void storage_classes()
{
	printf("Differences");
}

// Main function
int main()
{
	int n;
    while(1)
	{
		printf("Enter question number(1-11): ");
		scanf("%d", &n);
		switch(n)
		{
		case 1: global_extern_static_1(); break;
		case 2: global_extern_static_2(); break;
		case 3: global(); break;
		case 6: sum_main(); break;
		//case 7: register_variable(); break;
		case 8: print_main(); break;
		case 9: func_main(); break;
		case 10: f_main(); break;
		//case 12: main_12(); break;
		case 13: funt_main(); break;
		//case 14: compare(); break;
		case 15: fun_main(); break;
		case 16: storage_classes(); break;
		}
		printf("\n");
	}
	return 0;
}
