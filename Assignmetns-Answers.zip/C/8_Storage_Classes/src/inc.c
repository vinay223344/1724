void inc(void)
{
	extern int x;
	++x;
}
