void inc2(void)
{
	extern int x;
	++x;
}
