/*
 ============================================================================
 Name        : Assignment9.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

/*
#include <stdio.h>
#include <stdint.h>

__attribute__((noinline))
static inline uintptr_t read_sp(void)
{
	uintptr_t sp;
	#if defined(_riscv)
	// RISC-V: copy SP into a general register
	__asm__ __volatile__("mv %0, sp":"=r"(sp));

	#elif defined(__aarch64__)
	// ARM64/AArch64
	__asm__ __volatile__("mov %0,sp":"=r"(sp));

	#elif defined(__arm__)
	// ARM32(ARM mode). If you're in Thumb, many toolchains still accept this.
	__asm__ __volatile__("mov %0,sp":"=r"(sp));

	#elif defined(__x86_64__)
	// x86-64 (AT&T syntax)
	__asm__ __volatile__("movq %%rsp,%0":"=r"(sp));

	#elif defined(__i386__)
	// x86 (32-bit)
	__asm__ __volatile__("movl %%esp,%0":"=r"(sp));

	#else
	// Fallback: approximate the stack position by taking the address of a local
	volatile int local = 0;
	sp = (uintptr_t)(void*)&local;
	#endif

	return sp;
}

void level3(int z)
{
	int l3 = z + 3;
	printf("[level3] SP = %#016lx & l3 = %p z = %d\n", (unsigned long) read_sp(), (void*)&l3, z);
}

void level2(int y)
{
	int l2 = y + 2;
	printf("[level2] SP = %#016lx &l2 = %p y = %d\n", (unsigned long)read_sp(),(void*)&l2,y);
	level3(l2);
	printf("[level2] after level3 SP = %#016lx\n", (unsigned long)read_sp());
}

void level1(int x)
{
	int l1 = x + 1;
	printf("[level1] SP = %#016lx &l1 = %p x = %d\n", (unsigned long)read_sp(),(void*)&l1, x);
	level2(l1);
	printf("[level1] after level2 SP = %#016lx\n", (unsigned long)read_sp());
}

int main()
{
	int main_local = 42;
	printf("[main] SP = %#016lx &main_local = %p\n", (unsigned long)read_sp(), (void*)&main_local);
	level1(main_local);
	printf("[main] after level1 SP = %#016lx\n", (unsigned long)read_sp());
	return 0;
}*/
/* Output:  [main] SP = 0x007ffef858df50 &main_local = 0x7ffef858df64
			[level1] SP = 0x007ffef858df20 &l1 = 0x7ffef858df44 x = 42
			[level2] SP = 0x007ffef858def0 &l2 = 0x7ffef858df14 y = 43
			[level3] SP = 0x007ffef858dec0 & l3 = 0x7ffef858dee4 z = 45
			[level2] after level3 SP = 0x007ffef858def0
			[level1] after level2 SP = 0x007ffef858df20
			[main] after level1 SP = 0x007ffef858df50
*/
/* Explanation: Stack flows downwards and since the values for variables are assigned using pointers, their value changes. */

/*
#include <stdio.h>

void f3(void)
{
	int a3 = 3;
	printf("[f3] &a3 = %p\n", (void*)&a3);
}

void f2(void)
{
	int a2 = 2;
	printf("[f2] &a2 = %p\n", (void*)&a2);
	f3();
	printf("[f2] after f3 &a2=%p\n", (void*)&a2);
}

void f1(void)
{
	int a1 = 1;
	printf("[f1] &a1 = %p\n", (void*)&a1);
	f2();
	printf("[f1] after f2 &a1 = %p\n", (void*)&a1);
}

int main(void)
{
	int m = 0;
	printf("[main] &m = %p\n", (void*)&m);
	f1();
	printf("[main] after f1 &m = %p\n",(void*)&m);
	return 0;
}*/
/* Output:  [main] &m = 0x7ffeb5b86b54
			[f1] &a1 = 0x7ffeb5b86b34
			[f2] &a2 = 0x7ffeb5b86b14
			[f3] &a3 = 0x7ffeb5b86af4
			[f2] after f3 &a2=0x7ffeb5b86b14
			[f1] after f2 &a1 = 0x7ffeb5b86b34
			[main] after f1 &m = 0x7ffeb5b86b54
*/
/* Explanation: Stack flows downwards and since the values for variables are assigned using pointers */

/*
#include<stdio.h>
int f(int);
int main()
{
	int i=3, val;
	val = f(i+=2) + f(i=1) + f(i++);
	printf("%d %d", i, val);
	return 0;
}
int f(int num)
{
	return num*5;
}*/
/* Output: 2 35 */
/* Explanation: i = 3
 				val = f(i+=2) + f(i=1) + f(i++)
 				f(i+=2) => f(5) => 25
 				f(i=1) => f(1) => 5
 				f(i++) => f(1) => 5
 				val = 25 + 5 + 5 = 35
 				i = 2
*/

/*
#include<stdio.h>
int func(int i)
{
	if(i%2) return 0;
	else return 1;
}
int main()
{
	int i = 3;
	i = func(i);
	i = func(i);
	printf("%d",i);
}*/
/* Output: 1 */
/* Explanation: i = 3
				i = f(3) => 3%2 = 1 => i = 0
				i = f(0) => 0%2 = 0 => i = 1
*/

/*
#include<stdio.h>
int counter(int i)
{
	static int count = 0;
	count = count + i;
	return(count);
}
int main()
{
	int i,j;
	for(i = 0;i <= 5; i++)
	j = counter(i);
	printf("%d",j);
}*/
/* Output: 15 */
/* Explanation: static variable is initialized only once.
				Each time the function is called, the i value is added to count.
				i = 0 => count = 0 + 0 = 0
				i = 1 => count = 0 + 1 = 1
				i = 2 => count = 1 + 2 = 3
				i = 3 => count = 3 + 3 = 6
				i = 4 => count = 6 + 4 = 10
				i = 5 => count = 10 + 5 = 15
*/

/*
#include<stdio.h>
int main()
{
	int x,y;
	y = 5;
	x = func(y++);
	(x == 5) ? printf("true") : printf("false");
}
int func(int z)
{
	if(z==6)
	return 5;
	else
	return 6;
}*/
/* Output: false */
/* Explanation: x = func(y++) => func(5) => z==6 => not true => is returned.
				x = 6
				(x==5) =>false => false is printed
*/

/*
#include<stdio.h>
int main()
{
	int x;
	x = 3;
	f(x);
	printf("MAIN");
}
int f(int n)
{
	printf("F ");
	if(n != 0)
	f(n-1);
}*/
/* Output: F F F F MAIN */
/* Explanation: F is printed for i = 3,2,1,0 and then control comes out of the function and prints MAIN. */

/*
#include<stdio.h>
int main()
{
	int a = 5;
	a = find(a+=find(a++));
	printf("%d",a);
}
int find(int a)
{
	return(a++);
}*/
/* Output: 11 */
/* Explanation: a = find(a+=find(a++))
				find(a++) => find(5); a=6 => returns 5 and is incremented to 6 in function locally.
				a+=5 => a = 6 + 5 = 11
			    find(a++) => returns 11 => a = 11
*/

/*
#include<stdio.h>
int main()
{
	int a = 5;
	printf("in main: %d, %d\n",a++, ++a);
	fn(a,++a);
}
void fn(int a, int b)
{
	printf("fn: %d, %d",a,b);
}
/* Output: */
/* Explanation: printf -> right to left evaluation, check once*/

/*
#include<stdio.h>
int fn(int v)
{
	if(v==1 || v==0)
	return 1;
	if(v%2 == 0)
	return fn(v/2)+2;
	else
	return fn(v-1)+3;
}
int main()
{
	printf("%d", fn(7));
}*/
/* Output: 11 */
/* Explanation: f(7) => f(6) + 3
				f(6) => f(3) + 2
				f(3) => f(2) + 3
				f(2) => f(1) + 2
				f(1) => 1
				f(2) => f(1) + 2 => 1 + 2 = 3
				f(3) => f(2) + 3 => 3 + 3 = 6
				f(6) => f(3) + 2 => 6 + 2 = 8
				f(7) => f(6) + 3 => 8 + 3 = 11
*/

/*
#include<stdio.h>
int x = 5;
void print()
{
	printf("%d",x--);
}
int main()
{
	print();
}*/
/* Output: 5 */
/* Explanation: 5 is printed and then decremented*/

/*
#include<stdio.h>
int main()
{
	int n=10;
	int func(int);
	printf("%d",func(n));

}
int func(int n)
{
	if(n>0)
	return(n+func(n-2));
	else return 0;
}*/
/* Output: 30 */
/* Explanation: func(10) => 10 + func(8)
 	 	 	 	func(8) => 8 + func(6)
 	 	 	 	func(6) => 6 + func(4)
 	 	 	 	func(4) => 4 + func(2)
 	 	 	 	func(2) => 2 + func(0)
 	 	 	 	func(0) => 0
 	 	 	 	func(10) => 10 + 8 + 6 + 4 + 2 + 0 => 30
*/

/*
#include<stdio.h>
int temp(int);
int main()
{
	int n;
	n = temp(6);
	printf("%d",n);
}
int temp(int n)
{
	if(n<=1) return 1;
	else return(temp(n-3)+temp(n-1));
}*/
/* Output: 9 */
/* Explanation: f(-1) = f(0) = f(1) = 1
				f(2) = f(-1) + f(1) = 1 + 1 = 2
				f(3) = f(2) + f(1) = 2 + 1 = 3
				f(4) = f(1) + f(3) = 1 + 3 = 4
				f(5) = f(2) + f(4) = 2 + 4 = 6

				temp(6) => temp(3) + temp(5) => 3 + 6 = 9
*/

/*
#include<stdio.h>
int main()
{
	int num = _temp_123(4);
	printf("%d", --num);
	return 0;
}
int _temp_123(int num)
{
	return(num++);
}*/
/* Output: 3 */
/* Explanation: 4 is returned and then incremented.
				In print statement, the value of num is decremented and printed.
*/

/*
#include<stdio.h>
int main()
{
	int a = 25, b = 24, c;
	printf("%d", function(a+2,b+3));
}
int function(int x,int y)
{
	return (x-(x==y));
}*/
/* Output: 26 */
/* Explanation: f(27,27) => 27 - (27 == 27) => 27 - 1 = 26.*/
