#include <stdio.h>

int x = 10;
void inc(void);
int main(void) {
	printf("%d ",x);
	inc();
	printf("%d ",x);
	inc();
	printf("%d ",x);
	inc();
	printf("%d ",x);
}

