#include<stdio.h>
static int i=9;
void main()
{
	printf("Hi");
}
