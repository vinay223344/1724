src/Example.o: ../src/Example.c
