/*
 ============================================================================
 Name        : Example.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
/*
unsigned char f1(int a , int b)
{
	int c = 0x1234;
	printf("%x ",c);
	return c;
}
int main(void) {
	int c;
	c= f1(10,80);
	printf("%x",c);
}
*/

/*
#include<stdio.h>

#define MAX 10
#define COUNT 8

int main()
{
	int i=1;
	int b;
	#if MAX
		for(i=0;i<MAX;i++)
		{
		#if COUNT
				i = COUNT;
		#endif
			printf("%d",i);
		}
	#endif
	return 0;
}
*/
/*
#include <stdio.h>
#define MAX 1000
int main()
{
int MAX = 100;
printf("%d ", MAX);
return 0;
}*/


// 1. C function to print binary representation of a positive integer n using recursion
void binary(int n, int bin, int a)
{
	int rem = 0;
	if(n==0)
	{
		printf("%d",bin);// Print the binary number when the original number is 0
		return;
	}
	rem = n % 2;		// Obtain the rem when divided by 2
	bin = bin + rem * a;// Append the remainder to the binary number
	n = n / 2;			// Divide the number by 2
	a = a * 10;			// Change placevalue of 'a' so as to move the bin number a digit towards left
	binary(n, bin, a);  // Call the binary() function recursively
}
int main()
{
	int num, bin = 0, a = 1;
	printf("Enter a positive integer: ");
	scanf("%d", &num); // Read a positive integer
	binary(num,bin,a); // Call binary function with arguments: number, initialized binary, placevalue variable
}
