import re

print(re.search(r'(?<=can)did','candid'))
#<re.Match object; span=(3, 6), match='did'>

print(re.search(r'(?<=not)did','candid'))
# None

# print(re.search(r'(?<=a+)def','aaadef'))
# re.error: look-behind requires fixed-width pattern

print(re.search(r'(?<=a{3})def','aaadef'))
# <re.Match object; span=(3, 6), match='def'>

print(re.search(r'(?<!can)did','candid'))
# None

print(re.search(r'(?<!not)did','candid'))
# <re.Match object; span=(3, 6), match='did'>

