import re

str1 = """Let's understand how regex works
"""
print(re.search('regex',str1))
# Output: <re.Match object; span=(21, 26), match='regex'>

print(str1[21:26])
# Output: regex

print(re.search('works\n', str1))
# Output: <re.Match object; span=(27, 33), match='works\n'>

str2 = "regex, regex - same words are repeated"
print(re.search('regex',str2))
# <re.Match object; span=(0, 5), match='regex'>

print(re.findall('regex',str2))
# ['regex', 'regex']
print(type(re.findall('regex',str2)))
# <class 'list'>
