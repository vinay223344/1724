import re

str3 = "I like PYTHON programming"

print(re.findall(r'[A-Z]+',str3))
# ['I', 'PYTHON']

str4 = "Numbers are 8,23,886,4567,78453" 
print(re.search(r'\d{5}',str4))
# <re.Match object; span=(26, 31), match='78453'>

print(re.findall(r'\b\d{2,4}\b',str4))
# ['23', '886', '4567']

str5 = "I am doing \n Assignment on regular expressions in PYTHON."
print(re.findall(r'\b\w+\b',str5))
# ['I', 'am', 'doing', 'Assignment', 'on', 'regular', 'expressions', 'in', 'PYTHON']

str6 = "These are the emails of different users tom.jerry@moschip.com, beauty.beast@moschip.com, nobitha.nobi@gmail.com mr.bean@gmail.com motu.patlu@nick.tic power.rangers@nick.com"
print(re.findall(r'([a-z]+\.[a-z]+@[a-z]+\.[a-z]+)',str6))
""" ['tom.jerry@moschip.com', 'beauty.beast@moschip.com', 'nobitha.nobi@gmail.com', 'mr.bean@gmail.com', 'motu.patlu@nick.tic', 'power.rangers@nick.com'] """

str7 = '''
123		Integer number with 3-digits
123.4567	Real number with 3-digits in whole number and 4-Digits in fractional portion
1234.0		Real number with 4-digits in whole number and 1-digit in fractional portion
4 		Integer number with 1-digit
4567		Integer number with 4-digits
6.0		Real number with 1-digit in whole number and 1-digit in fractional portion
78901		Integer number with 5-digits
56		Integer number with 2-digits
3.456		Real number with 1-digit in whole number and 3-digits in fractional portion
This line doesn't contain any numbers
10. 		is not a valid number
.10		is not a valid number
100e-10		Real number in scientific notation
100.0e-01	Real number in scientific notation
100.123e+1	Real number in scientific notation
123.e-		Invalid number
123.e+		Invalid number
.e-12		Invalid number
^		Caret
.		Dot
$		Dollar
*		Asterisk
+ 		Plus
? 		Question mark
{		Flower bracket
[		Square bracker
|		Pipe
(		Small bracket
& 		Ampersand
'''
print(re.findall(r'\s([0-9]+)\s',str7))
# ['123', '4', '4567', '78901', '56']

print(re.findall(r'\s([0-9]+[.][0-9]*[e]*[-+]*[0-9]+)\s',str7))
# ['123.4567', '1234.0', '6.0', '3.456', '100.0e-01', '100.123e+1']

print(re.findall(r'\n([^\d])\s',str7))
# ['^', '.', '$', '*', '+', '?', '{', '[', '|', '(', '&']


str8='''
Design		OP["IO/I1/M0" "vdsat")(V)
1.		2.656514e-02
Design		OP["IO/I1/M1" "vds")(V)
1.		5.087847e-01
Design		OP["IO/I1/M2" "id")(A)
1.		1.000000e-06
Design		OP["IO/I1/M3" "vth")(V)
1.		4.558458e-01
'''

print(re.findall(r'IO/I1/M[0-3]',str8))
# ['IO/I1/M0', 'IO/I1/M1', 'IO/I1/M2', 'IO/I1/M3']

print(re.findall(r'vdsat|vds|vth|id',str8))
# ['vdsat', 'vds', 'id', 'vth']

print(re.findall(r'[0-9]+[.][0-9]+[e][-+][0-9]+',str8))
# ['2.656514e-02', '5.087847e-01', '1.000000e-06', '4.558458e-01']



