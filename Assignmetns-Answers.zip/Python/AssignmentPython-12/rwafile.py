file1 = open('fileHandling.txt','r')
for each in file1:
	print(each)
file1.close()
'''
Hi all!

Let's learn File handling in python

First we create a text file.

'''

file1 = open('fileHandling.txt','r')
print(file1.read())
file1.close()
'''
Hi all!
Let's learn File handling in python
First we create a text file.
'''

with open('fileHandling.txt','r') as file1:
	print("Output of read function is ")
	print(file1.read())
'''
Output of read function is 
Hi all!
Let's learn File handling in python
First we create a text file.
'''

with open('fileHandling.txt','r') as file1:
	print("Output of read(5) function is ")
	print(file1.read(5))
'''
Output of read(5) function is 
Hi al
'''


with open('fileHandling.txt','r') as file1:
	print("Output of read(15) function is ")
	print(file1.read(15))
'''
Output of read(15) function is 
Hi all!
Let's l
'''



with open('fileHandling.txt','r') as file1:
	print("Output of readline(15) function is ")
	print(file1.readline(15))
'''
Output of readline(15) function is 
Hi all!
'''
	
	
with open('fileHandling.txt','r') as file1:
	print("Output of readline() function is ")
	print(file1.readline())
'''
Output of readline() function is 
Hi all!
'''


with open('fileHandling.txt','r') as file1:
	print("Output of readlines() function is ")
	print(file1.readlines())
'''
Output of readlines() function is 
['Hi all!\n', "Let's learn File handling in python\n", 'First we create a text file.\n', '\n']
'''

file1 = open('fileHandling.txt','r')
print("Reading and creating a list of words for each line of the file")
data = file1.readlines()
for line in data:
	word = line.split()
	print(word)
'''
Reading and creating a list of words for each line of the file
['Hi', 'all!']
["Let's", 'learn', 'File', 'handling', 'in', 'python']
['First', 'we', 'create', 'a', 'text', 'file.']
[]
'''


# with open('fileHandling1.txt','r') as file1:
#	print(file1.read())
# FileNotFoundError: [Errno 2] No such file or directory: 'fileHandling1.txt'




with open('fileHandling.txt','w') as file1:
	file1.write("This is write command\n")
	file1.write("It allows us to write into a file\n")
	file1.writelines(['1st line\n', '2nd line\n', '3rd line\n'])
	print('Output after writing into the file is: ')
with open('fileHandling.txt','r') as file1:
	print(file1.read())
'''
Output after writing into the file is: 
This is write command
It allows us to write into a file
1st line
2nd line
3rd line
'''


# with open('fileHandling.txt','w') as file1:
#	print(file1.read())
'''
io.UnsupportedOperation: not readable
'''

with open('fileHandling.txt','w') as file1:
	with open('fileHandling.txt','r') as file1:
		print(file1.read())
'''
(Empty file)
'''


with open('fileHandling.txt','a') as file1:
	file1.write('This is append command\n')
	file1.write('Using this command we can add text to the required file, without losing the previous data\n')
	print('Output after appending text into a file: ')
with open('fileHandling.txt','r') as file1:
	print(file1.read())
'''
Output after appending text into a file: 
This is append command
Using this command we can add text to the required file, without losing the previous data
'''

with open('fileHandling.txt','a') as file1:
	with open('fileHandling.txt','r') as file1:
		print(file1.read())
'''
This is append command
Using this command we can add text to the required file, without losing the previous data
'''

'''
with open('fileHandling.txt','a') as file1:
	print(file1.read())'''
# io.UnsupportedOperation: not readable


with open('fileHandling.txt','r+') as file1:
	print(file1.read())
	file1.write('This is read and write command(r+)\n')
	file1.write('Using this command we can read text and add text to the required file, without losing the previous data\n')
'''
This is append command
Using this command we can add text to the required file, without losing the previous data
'''


with open('fileHandling.txt','w+') as file1:
	file1.write('This is read and write command(w+)\n')
	file1.write('A new file can be created, if it an existing file then the contents of the file are overwritten \n')


with open('fileHandling.txt','a+') as file1:
	file1.write('This is read and append command(a+) \n')
	file1.write('We can read contents of the file and can append text at the end of the file \n')
	
	

with open('seek.txt','w+') as file2:
	file2.writelines(['First lines\n','Second line\n', 'Third line\n', 'Fourth line\n', 'Fifth line\n'])
	file2.seek(0)
	print(file2.read())
	file2.seek(3,0)
	print(file2.read())
	file2.seek(1)
	print(file2.read())
	file2.seek(0,2)
	print(file2.read())
'''
First lines
Second line
Third line
Fourth line
Fifth line

st lines
Second line
Third line
Fourth line
Fifth line

irst lines
Second line
Third line
Fourth line
Fifth line
'''
