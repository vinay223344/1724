import os
import shutil

print(os.getcwd)
# <built-in function getcwd>

print(os.getcwd())
# /home/engineer/Downloads/mastes0809/C/mastes08/mastes0809/Python/AssignmentPython-13

print(os.listdir(os.getcwd()))
# ['AssignmentPython-13.txt', 'osMethods.py']

#print(os.mkdir('osDir1',0o750))
# None

print(os.chmod('osDir1',0o755))
# None

'''
try:
	print(os.mkdir('osDir2/osDir3',0o755))
except OSError as error:
	print(error)
	os._exit(1)
# [Errno 2] No such file or directory: 'osDir2/osDir3'
'''
print(os.makedirs('osDir2/osDir3',0o755))
# None

print(shutil.rmtree("osDir2"))
# None

# print(type(shutil.rmtree("osDir2")))
# <class 'NoneType'>

loc = '/home/engineer/Downloads/mastes0809/C/mastes08/mastes0809/Python/AssignmentPython-13'
os.chdir(os.path.join(loc,'osDir1'))
os.open('myfile1.txt',os.O_RDWR | os.O_CREAT, 0o755)

print(os.path.exists('myfile1.txt'))
# True
print(type(os.path.exists('myfile1.txt')))
# <class 'bool'>

print(os.stat('myfile1.txt'))
# os.stat_result(st_mode=33261, st_ino=1327372, st_dev=2050, st_nlink=1, st_uid=1000, st_gid=1000, st_size=0, st_atime=1772190465, st_mtime=1772190465, st_ctime=1772190465)

print(os.remove('myfile1.txt'))
# None

os.chdir(loc)
print(os.listdir())
# ['AssignmentPython-13.txt', 'osMethods.py', 'osDir1']

#os.makedirs('osDir1/osDir2/osDir3/osDir4',0o755)
shutil.copytree('osDir1','copy_osDir1')
