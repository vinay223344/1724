import pandas as pd
df = pd.DataFrame({'Instance':['I0','I1','I2','I3','I4'],
		   'Vgs_in_mV':[650,575,820,700,950],
		   'Vth_in_mV':[453.7,475.6,495.6,462.8,472.3],
		   'Vdsat_in_mV':[149.5,125.4,148.3,139.8,145.6]})
print(df.head(3))
'''
  Instance  Vgs_in_mV  Vth_in_mV  Vdsat_in_mV
0       I0        650      453.7        149.5
1       I1        575      475.6        125.4
2       I2        820      495.6        148.3
'''

print(df.tail(2))
'''
  Instance  Vgs_in_mV  Vth_in_mV  Vdsat_in_mV
3       I3        700      462.8        139.8
4       I4        950      472.3        145.6
'''

df2 = pd.DataFrame({'Instance':['I5','I6','I7'],
		    'Vgs_in_mV':[720,630,800],
		    'Vth_in_mV':[485.7,490.5,493.6],
		    'Vdsat_in_mV':[200.4,198.4,180.1]})
new_df = pd.concat([df,df2],ignore_index=True)
print(new_df)
'''
  Instance  Vgs_in_mV  Vth_in_mV  Vdsat_in_mV
0       I0        650      453.7        149.5
1       I1        575      475.6        125.4
2       I2        820      495.6        148.3
3       I3        700      462.8        139.8
4       I4        950      472.3        145.6
5       I5        720      485.7        200.4
6       I6        630      490.5        198.4
7       I7        800      493.6        180.1
'''

df3 = pd.DataFrame({'Region':[2,1,2,3,3,2,1,3]})
new_df = pd.concat([new_df,df3],axis=1)
print(new_df)
'''
  Instance  Vgs_in_mV  Vth_in_mV  Vdsat_in_mV  Region
0       I0        650      453.7        149.5       2
1       I1        575      475.6        125.4       1
2       I2        820      495.6        148.3       2
3       I3        700      462.8        139.8       3
4       I4        950      472.3        145.6       3
5       I5        720      485.7        200.4       2
6       I6        630      490.5        198.4       1
7       I7        800      493.6        180.1       3
'''

new_df.set_index("Instance",inplace=True)
print(new_df)
'''
          Vgs_in_mV  Vth_in_mV  Vdsat_in_mV  Region
Instance                                           
I0              650      453.7        149.5       2
I1              575      475.6        125.4       1
I2              820      495.6        148.3       2
I3              700      462.8        139.8       3
I4              950      472.3        145.6       3
I5              720      485.7        200.4       2
I6              630      490.5        198.4       1
I7              800      493.6        180.1       3
'''

new_df['Vov_in_mV']=new_df.apply(lambda row:row.Vgs_in_mV - row.Vth_in_mV, axis=1)
print(new_df)
'''
          Vgs_in_mV  Vth_in_mV  Vdsat_in_mV  Region  Vov_in_mV
Instance                                                      
I0              650      453.7        149.5       2      196.3
I1              575      475.6        125.4       1       99.4
I2              820      495.6        148.3       2      324.4
I3              700      462.8        139.8       3      237.2
I4              950      472.3        145.6       3      477.7
I5              720      485.7        200.4       2      234.3
I6              630      490.5        198.4       1      139.5
I7              800      493.6        180.1       3      306.4
'''

new_df.drop(["I7","I6"],inplace=True)
print(new_df)
'''
          Vgs_in_mV  Vth_in_mV  Vdsat_in_mV  Region  Vov_in_mV
Instance                                                      
I0              650      453.7        149.5       2      196.3
I1              575      475.6        125.4       1       99.4
I2              820      495.6        148.3       2      324.4
I3              700      462.8        139.8       3      237.2
I4              950      472.3        145.6       3      477.7
I5              720      485.7        200.4       2      234.3
'''

new_df.drop(["Vov_in_mV"],axis=1,inplace=True)
print(new_df)
'''
          Vgs_in_mV  Vth_in_mV  Vdsat_in_mV  Region
Instance                                           
I0              650      453.7        149.5       2
I1              575      475.6        125.4       1
I2              820      495.6        148.3       2
I3              700      462.8        139.8       3
I4              950      472.3        145.6       3
I5              720      485.7        200.4       2
'''

print(new_df.describe())
'''
        Vgs_in_mV   Vth_in_mV  Vdsat_in_mV    Region
count    6.000000    6.000000     6.000000  6.000000
mean   735.833333  474.283333   151.500000  2.166667
std    132.454395   15.139011    25.527867  0.752773
min    575.000000  453.700000   125.400000  1.000000
25%    662.500000  465.175000   141.250000  2.000000
50%    710.000000  473.950000   146.950000  2.000000
75%    795.000000  483.175000   149.200000  2.750000
max    950.000000  495.600000   200.400000  3.000000
'''

copy_df=new_df.copy(deep=False)
copy_df.loc['I1','Vgs_in_mV']=725
print("Before Copy:\n",new_df)
print("After Copy:\n",copy_df)
'''Before Copy:
           Vgs_in_mV  Vth_in_mV  Vdsat_in_mV  Region
Instance                                           
I0              650      453.7        149.5       2
I1              725      475.6        125.4       1
I2              820      495.6        148.3       2
I3              700      462.8        139.8       3
I4              950      472.3        145.6       3
I5              720      485.7        200.4       2
After Copy:
           Vgs_in_mV  Vth_in_mV  Vdsat_in_mV  Region
Instance                                           
I0              650      453.7        149.5       2
I1              725      475.6        125.4       1
I2              820      495.6        148.3       2
I3              700      462.8        139.8       3
I4              950      472.3        145.6       3
I5              720      485.7        200.4       2
'''


