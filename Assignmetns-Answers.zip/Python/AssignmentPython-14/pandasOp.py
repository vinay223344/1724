import pandas as pd
df = pd.DataFrame()

print(df)
'''
Empty DataFrame
Columns: []
Index: []
'''

print(type(df))
# <class 'pandas.core.frame.DataFrame'>

lst = ['Width', 'Length', 'Vth', 'VGS', 'VDS', 'Vsat', 'Rout', 'gm']
df = pd.DataFrame(lst)
print(df)
'''
        0
0   Width
1  Length
2     Vth
3     VGS
4     VDS
5    Vsat
6    Rout
7      gm
'''

data = {'Process':['tt','ss','sf','fs','ff'],
	'Voltage':[1.8,1.62,1.98,1.2,0.8]}
df = pd.DataFrame(data)
print(df[['Process']])
'''
  Process
0      tt
1      ss
2      sf
3      fs
4      ff
'''
temperature = [300, 373, 273, 250, 300]
df['Temperature']=temperature
print(df)
'''
  Process  Voltage  Temperature
0      tt     1.80          300
1      ss     1.62          373
2      sf     1.98          273
3      fs     1.20          250
4      ff     0.80          300
'''

df.set_index('Process',inplace=True)
print(df)
'''
         Voltage  Temperature
Process                      
tt          1.80          300
ss          1.62          373
sf          1.98          273
fs          1.20          250
ff          0.80          300
'''

row_data = df.loc["sf"]
print(row_data)
'''
Voltage          1.98
Temperature    273.00
Name: sf, dtype: float64
'''

row_data = df.iloc[0,:]
print(row_data)
'''
Voltage          1.8
Temperature    300.0
Name: tt, dtype: float64
'''
