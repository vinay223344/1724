var1 = (1,2,3)[0]
var2 = (1,2,3)[1]
#var3 = (1,2,3)[3]
var4 = (1,2,3)[-1]
var5 = (1,2,3)[-3]
#var6 = (1,2,3)[-4]
var7 = (1,2,3)
var8 = (1,2,3)[len(var7)-1]
var9 = (1,2,3)[-len(var7)]
#var10 = (1,2,3)*2[-len(var7)*2]
var11 = ((1,2,3)*2)[-len(var7)*2]
var12 = ((1,2,3)[-len(var7)])*2
var13 = (((1,2,3)[-len(var7)]))*2
var14 = (1,2,3)[0:1]
var15 = (1,2,3)[:1]
var1 = (1,2,3)[0]
var16 = (1,2,3)[:-1]
var17 = (1,2,3)[-4:-1]
var18 = (1,2,3)[-3:]
var19 = ((1,2,3)[0],(1,2,3)[-2],(1,2,3)[2:3])

print(var1)
print(var2)
print(var4)
print(var5)
print(var7)
print(var8)
print(var9)
print(var11)
print(var12)
print(var13)
print(var14)
print(var15)
print(var16)
print(var17)
print(var18)
print(var19)

