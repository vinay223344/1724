tuple1 = ('You', 'ca\'t', 'replace', 'me')
print(tuple1)
#tuple1[0] = 'I'
#tuple1[0] = 'You'
#tuple1[0:1] = ('I', 'can')
tuple1 = ('I', 'can', 'replace', 'you')
print(tuple1)

