list1 = [1,2,3][0]
list2 = ([[1,2],(3,)]*2)
print('Type of list2: ', type(list2))

var3 = list2[0][0]
var4 = list2[0][0:1]
print('Type of var3: ', type(var3))
print('Type of var4: ', type(var4))

#var5 = [0,1,2,3,4,5][6]
list6 = [0,1,2,3,4,5][0:6]
list7 = [0,1,2,3,4,5][6:7]
print('Type of list7: ', type(list7))
print('Length of list7: ', len(list7))

list8 = [[1,2,3],(4,5,6),[[-1,-2,-3]]]
list9 = list8[len(list8)-1][-len(list8[2])][len(list8[2])-1]
list10 = list8[2:][0:1][0][0]
print(list8, list9, list10)



