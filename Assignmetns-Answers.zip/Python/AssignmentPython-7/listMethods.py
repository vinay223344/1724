List1 = list()
#List1.append("I don't leave you empty")
print("Return value of List1: ", List1.append("I don't leave you empty"))
print('Length of list(): ', len(List1))
List1.append(["I'm list", "but I'll be an element in List1"])
print('Length of List1[1]: ', len(List1[1]))
# List1.append(0,0)
List1 = List1.append("I'm setting you to None")
print('List1 = ', List1)
print('Type of List1: ', List1)

myList = [1,2,3,4]
yourList = [5,6,7,8]
print(myList.extend(yourList))
print(myList)
myList = myList + yourList
hisTuple = (9,10)
myList.extend(hisTuple)
print(myList)
herString = "0123"
myList.extend(herString)
print(myList)
#myList = myList + hisTuple
#myList = myList + herString

oldList = [-1,-2,-3]
newList = [0,1,2]
#oldList.append(newList)
#print(oldList)
oldList.extend(newList)
print(oldList)
#newList.extend(0) 
#newList.extend("1","2") 


List1 = [1,2,4,5]
print(len(List1))
print(List1.insert(2,3)) 
print(List1)
print(len(List1))

List1.append([0,1,2,3,5])
print(List1)
#List1[5].insert([4,4])
print(List1)

#List1.insert(6,6)
print(List1) # [1, 2, 3, 4, 5, [0, 1, 2, 3, 5], 6]
#List1.append(6)
print(List1) # [1, 2, 3, 4, 5, [0, 1, 2, 3, 5], 6, 6]
List1.extend([6]) 
print(List1) # [1, 2, 3, 4, 5, [0, 1, 2, 3, 5], 6]

#List1.insert(7,[7,8,9]) # [1, 2, 3, 4, 5, [0, 1, 2, 3, 5], 6, [7, 8, 9]]
#List1.append([7,8,9]) # [1, 2, 3, 4, 5, [0, 1, 2, 3, 5], 6, [7, 8, 9]]
List1.extend([7,8,9]) # [1, 2, 3, 4, 5, [0, 1, 2, 3, 5], 6, 7, 8, 9]
print(List1)

List1.insert(100,10)
print(List1) # [1, 2, 3, 4, 5, [0, 1, 2, 3, 5], 6, 7, 8, 9, 10]



List1 = ["L1",10,20,10,20]
print(List1.index(10)) # Return value: 1
#print(List1.index(100)) # ERROR: Since no element called 100


List1 = ["I", "may", "be", "removed"]
List1.remove("i".upper())
print(List1) # ['may', 'be', 'removed']
#List1.remove("You") # "You" element is not present. Hence error is shown
List1.insert(0,"You")
print(List1) # ['You', 'may', 'be', 'removed']
#print(List1.remove("I".title())) # Element not found error
print(List1.pop(0)) # You
print(len(List1)) # 3
print(List1.pop()) # removed
print(len(List1)) # 2


List1 = [1,2,3,4]
#List1.remove(2) # [1, 3, 4]
#List1.pop(1) # [1, 3, 4]
del List1[1] # [1, 3, 4]
print(List1) 

 
List1.clear() # []
print(List1) 
del List1 # name 'List1' is not defined
print(List1)


