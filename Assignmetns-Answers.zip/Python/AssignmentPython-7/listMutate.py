List1 = list()
print('Type of list(): ', type(List1))
print('Length of list(): ', len(List1))

#List1[0] = [1,2,3]
List1 = list((list(),list(),list()))
print('Type of list(): ', type(List1))
print('Length of list(): ', len(List1))

List1[0] = [1,2,3]
print(List1)
List1 = "123"
print(List1)
List1[2] = List1[1][1]



