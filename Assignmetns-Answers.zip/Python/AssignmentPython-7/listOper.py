print('Length of list [1,2,3] is ', len([1,2,3]))
print('Length of list [1,2,] is ', len([1,2,]))
print('Length of list [[1,2,3]] is ', len([[1,2,3]]))
print('Length of tuple ((1,2,3)) is ', len(((1,2,3))))

print('Data type of tuple [[1]] is ', type([[1]]))
print('Data type of ((1)) is ', type(((1))))

print('List expr [1]+[2] is ', [1]+[2])
print('Tuple expr (1)+(2) is ', (1)+(2))
#print('List expr [1]*[2] is ', [1]*[2])

#print('List expr [1]*2 is ', [1]*2)
#print('List expr ['1']*2 is ', ['1']*2)
#print('Expr ['1']*(2) is ', ['1']*(2))


mat3x3 = [ [1,2,3], (-1,-2,-3), ['a','b','c'],]
print("""Mat1 = [[1,2,3],(-1,-2,-3),['a','b','c'],] """, mat3x3, sep= '=')
mat6x3 = mat3x3 + mat3x3
mat2x2 = [[1,2],[2,1]]
mat8x32 = mat6x3 + mat2x2
print(mat8x32)
 
