dict1 = {
	'circuitName' : "Amplifier" ,
	'biasCurrent' : 10.0e-6 ,
	'powerSupply' : 1.8 ,
	'mosType' : ["LVTPFET", "LVTNFET"] ,
	'noFets' : 20
	}
dict2 = {
   	   'circuit1' : dict1,
   	   'resVal' : 10e03,
   	   'refVolt' : 1.2
   	   }
dictKeys = dict1.keys()
print(dictKeys)
# dict_keys(['circuitName', 'biasCurrent', 'powerSupply', 'mosType', 'noFets'])
print(type(dictKeys))
# <class 'dict_keys'>


dictVals = dict1.values()
print(dictVals)
# dict_values(['Amplifier', 1e-05, 1.8, ['LVTPFET', 'LVTNFET'], 20])
print(type(dictVals))
# <class 'dict_values'>

dictitems = dict1.items()
print(dictitems)
# <class 'dict_items'>
print(type(dictitems))
# {'resVal': 10000.0, 'refVolt': 1.2}

var1 = dict2.pop('circuit1')
print(dict2)
# {'resVal': 10000.0, 'refVolt': 1.2}
print(type(dict2))
# <class 'dict'>

#val2 = dict2.pop()
# TypeError: pop expected at least 1 argument, got 0

dict1.clear()
print(dict1)
# {}

del dict1
print(dict1)
# name 'dict1' is not defined
