dict1 = {}
print(type(dict1))
# <class 'dict'>

dict1 = {
	'circuitName' : "Amplifier" ,
	'biasCurrent' : 10.0e-6 ,
	'powerSupply' : 1.8 ,
	'mosType' : ["LVTPFET", "LVTNFET"] ,
	'noFets' : 20
	}
print(len(dict1))
# 5 

print(dict1)
# {'circuitName': 'Amplifier', 'biasCurrent': 1e-05, 'powerSupply': 1.8, 'mosType': ['LVTPFET', 'LVTNFET'], 'noFets': 20}

print(dict1['mosType'])
# ['LVTPFET', 'LVTNFET']

print(dict1['mosType'][0])
# LVTPFET

dict1['biasCurrent'] = 20.0e-06
print(dict1['biasCurrent'])
# 2e-05

dict1['temp'] = 27
print(dict1)
# {'circuitName': 'Amplifier', 'biasCurrent': 2e-05, 'powerSupply': 1.8, 'mosType': ['LVTPFET', 'LVTNFET'], 'noFets': 20, 'temp': 27}

#print(dict1['leakage'])
# KeyError: 'leakage'

del dict1['noFets']
print(dict1)
# {'circuitName': 'Amplifier', 'biasCurrent': 2e-05, 'powerSupply': 1.8, 'mosType': ['LVTPFET', 'LVTNFET'], 'temp': 27}

del dict1
dict1 = {
	'circuitName' : "Amplifier" ,
	'biasCurrent' : 10.0e-6 ,
	'powerSupply' : 1.8 ,
	'mosType' : ["LVTPFET","LVTNFET"] ,
	'noFets' : 20 ,
	'powerSupply' : 1.62
	}
print(dict1['powerSupply'])
# 1.62

v2idict1 = {
   	   'circuit1' : dict1,
   	   'resVal' : 10e03,
   	   'refVolt' : 1.2
   	   }
print(v2idict1['circuit1']['mosType'][0])
# LVTPFET

v2idict1['circuit1']['noFets'] = 15
print(v2idict1)
# {'circuit1': {'circuitName': 'Amplifier', 'biasCurrent': 1e-05, 'powerSupply': 1.62, 'mosType': ['LVTPFET', 'LVTNFET'], 'noFets': 15}, 'resVal': 10000.0, 'refVolt': 1.2}

print(dict1)
# {'circuitName': 'Amplifier', 'biasCurrent': 1e-05, 'powerSupply': 1.62, 'mosType': ['LVTPFET', 'LVTNFET'], 'noFets': 15}

