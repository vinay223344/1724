i1 = 1; i2 = 0; f1 = 11; f2 = 0.0; s1 = 'str'; s2 = ""; l1 = [1,2,3]; l2 = []; t1 = (); t2 = (1,2,3); d1 = {}; d2 = {"m1" : "PMOS", "m2" : "NMOS"}; b1 = True; b2 = False; n1 = None; s3 = " ";


# for x in i1:
#     print(x)
# TypeError: 'int' object is not iterable
# for x in i2:
#     print(x)
# TypeError: 'int' object is not iterable
# for x in f1:
#     print(x)
# TypeError: 'int' object is not iterable
# for x in f2:
#     print(x)
# TypeError: 'int' object is not iterable
for x in s1:
    print(x)
# s
# t
# r
for x in s2:
    print(x)
# 
for x in l1:
    print(x)
# 1
# 2
# 3
for x in l2:
    print(x)
# 
for x in t1:
    print(x)
# 
for x in t2:
    print(x)
# 1
# 2
# 3
for x in d1:
    print(x)
# 
for x in d2:
    print(x)
# m1
# m2
# for x in b1:
#     print(x)
# TypeError: 'bool' object is not iterable
# for x in b2:
#     print(x)
# TypeError: 'bool' object is not iterable
# for x in n1:
#     print(x)
# TypeError: 'NoneType' object is not iterable
for x in s3:
    print(x)
# 
print(d2.items())
# dict_items([('m1', 'PMOS'), ('m2', 'NMOS')])

for i in range(0,10,2):
    print(i)
# 0
# 2
# 4
# 6
# 8

for i in range(0,4):
    for j in range(0,4):
        print(i,j)
# 0 0
# 0 1
# 0 2
# 0 3
# 1 0
# 1 1
# 1 2
# 1 3
# 2 0
# 2 1
# 2 2
# 2 3
# 3 0
# 3 1
# 3 2
# 3 3

instances = ["m1", "m2", "r1", "c1"]
cellNames = ["PMOS", "NMOS", "Resistor", "Capacitor"]
for i, c in zip(instances, cellNames):
    print(i, "is", c)
# m1 is PMOS
# m2 is NMOS
# r1 is Resistor
# c1 is Capacitor
print(type(zip(instances, cellNames)))
# <class 'zip'>

for I in 'engineer':
    if I == 'i' or I == 'n':
        continue
    print("current letter: ", I)
# current letter:  e
# current letter:  g
# current letter:  e
# current letter:  e
# current letter:  r

fruits = ["apple", "banana", "cherry"]
for x in fruits:
    print(x)
    if x == "banana":
        break
# apple
# banana

fruits = ["apple", "banana", "cherry"]
for x in fruits:
    if x == "banana":
        break
    print(x)
# apple

for x in range(5):
    print(x)
else:
    print("Finally finished!")
# 0
# 1
# 2
# 3
# 4
# Finally finished!

for I in 'engineer':
    if I == 'i' or I == 'n':
        pass
    print("current letter: ", I)
# current letter:  e
# current letter:  n
# current letter:  g
# current letter:  i
# current letter:  n
# current letter:  e
# current letter:  e
# current letter:  r


  



