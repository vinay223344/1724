a = 10; b=20
if b > a:
    print("b is greater than a")
#if b > a:
print("b is greater than a")
# Identation is must in python    

# b is greater than a
# b is greater than a

c = 10; d = 10
if c > d:
    print("c is greater than d")
elif c == d:
    print("c and d are equal")
# c and d are equal


x = 10; y = 5
if x < y:
    print("x is less than y")
else:
    print("x is greater than y")
# x is greater than y

if b > a: print("b is greater than a"); print("hi")
# b is greater than a

print(x) if x > y else print(y)
# 10

p = 10; q = 20; r = 30
if r > p and r > q: print("Both conditions are true")
# Both conditions are true
if p < q < r: print("p<q<r equivalent to p<q and q<r")
# p<q<r equivalent to p<q and q<r
if p > q or r > p: print("out of 2 conditions, 1 condition is true")
# out of 2 conditions, 1 condition is true
print(print(True))  
# True
# None

if print("hello"): print("hi")
# hello

if not print("hello"): print("hi")
# hello
# hi

i1 = 1; i2 = 0; f1 = 11; f2 = 0.0; s1 = 'str'; s2 = ""; l1 = [1,2,3]; l2 = []; t1 = (); t2 = (1,2,3); d1 = {}; d2 = {"m1" : "PMOS", "m2" : "NMOS"}; b1 = True; b2 = False; n1 = None; s3 = " ";
if i1: print(i1) # 1
if i2: print(i2)
if f1: print(f1) # 11
if f2: print(f2)
if s1: print(s1) # str
if s2: print(s2)
if l1: print(l1) # [1,2,3]
if l2: print(l2)
if t1: print(t1)
if t2: print(t2) # (1,2,3)
if d1: print(d1)
if d2: print(d2) # {"m1" : "PMOS", "m2" : "NMOS"}
if b1: print(b1) # True
if b2: print(b2)
if n1: print(n1)
if s3: print(s3)
