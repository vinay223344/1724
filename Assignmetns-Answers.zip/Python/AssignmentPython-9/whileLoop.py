i = 1
while i < 6:
    print(i)
    i += 1
# 1
# 2
# 3
# 4
# 5

i = 0
a = 'moship'
while i < len(a):
    if a[i] == 's' or a[i] == 'i':
        i += 1
        break
    print('Current Letter: ', a[i])
    i += 1
# Current Letter:  m
# Current Letter:  o
  
while i < len(a):
    if a[i] == 's' or a[i] == 'i':
        i += 1
        continue
    print('Current Letter: ', a[i])
    i += 1
# Current Letter:  m
# Current Letter:  o
# Current Letter:  h
# Current Letter:  p

 
while i < len(a):
    if a[i] == 's' or a[i] == 'i':
        i += 1
        pass
    print('Current Letter: ', a[i])
    i += 1
# Current Letter:  m
# Current Letter:  o
# Current Letter:  h
# Current Letter:  p

i = 0
while i < 3:
    i += 1
    print(i)
else:
    print("No Break\n")
# 1
# 2
# 3
# No Break

i = 0
while i < 3:
    i += 1
    print(i)
    break
else:
    print("No Break")
# 1

a = [1,2,3,4]
while a:
    print(a.pop())
# 4
# 3
# 2
# 1
   
    
