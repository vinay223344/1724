import sys
import os
import re

if len(sys.argv) < 2:
	print("Required number of command line arguments are not provided!")
	os._exit(1)
if os.path.exists(sys.argv[1]):
	verilog_file = sys.argv[1]
else:
	print("The verilog file does not exist!")
	os._exit(1)
	
	
tb_verilog_file = 'tb_' + verilog_file
if os.path.exists(tb_verilog_file):
	print("The testbench file already exists, do you want to overwrite it?(Y/N)")
	res = input()
	if res == 'N' or res == 'n':
		os._exit(1)
	elif res == 'Y' or res == 'y':
		os.remove(tb_verilog_file)
		os.open(tb_verilog_file,os.O_RDWR | os.O_CREAT, 0o755)
		print("The testbench file is overwritten.")
	else:
		print("Invalid response")
		os._exit(1)
else:
	os.open(tb_verilog_file, os.O_RDWR | os.O_CREAT, 0o755)	
	print("The testbench file is created.")
	
	
with open(verilog_file,'r') as file1:
	line = file1.readline()
	file1.seek(0)
	data=file1.read()
	module = re.findall(r'\bmodule\s+\w+',line)
	module_name = (module[0].split())[1]
	input1 = re.findall(r"(?<=input)\s+[\w\s,]+(?=output)|(?<=input)\s+[\w\s,]+|(?<=input)\s+[\d:\d]\s*[\w\s,]+(?=output)|(?<=input)\s+[\d:\d]\s*[\w\s,]+",data)
	output1 = re.findall(r"(?<=output)\s+[\w\s,]+\s*(?=input)|(?<=output)\s+[\w\s,]+|(?<=output)\s+[\d:\d]\s*[\w\s,]+(?=input)|(?<=output)\s+\[\d:\d\]\s*[\w\s,]+",data)
	print(input1)
	print(output1)
	tb_name = module_name + '_tb'
	print(tb_name)
	print(input1[0].split(','))
	y = input1[0].split(',')
	print(y[0].split())
	print(input1[1].split())


