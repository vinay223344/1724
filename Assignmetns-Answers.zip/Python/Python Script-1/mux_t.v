module mux_t(output o1, input a1,b1, sel1 ,output [2:0]s1);
	input a, b;
	input sel;
	output o;
	o = ~sel.a + sel.b;
endmodule

